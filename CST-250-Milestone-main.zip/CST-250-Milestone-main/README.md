# CST-250-Milestone
## CST-250 Milestone 6

In this milestone, students will create a Playerstats class that models a player's game data, as well as adds a "high score" page to the application.

Windows Form Start Menu:

![alt text](https://github.com/JLAGCU/CST-250-Milestone/blob/main/Images/Difficulty%20Form%201.png?raw=true)


Windows Form Highscores:

![alt text](https://github.com/JLAGCU/CST-250-Milestone/blob/main/Images/HighScores%20Form%201.png?raw=true)


Windows Form Submit Highscore:

![alt text](https://github.com/JLAGCU/CST-250-Milestone/blob/main/Images/Winner%20Form%201.png?raw=true)